<!DOCTYPE html>
<HTML>
<title>user form</title>
<style>
    .a {
        text-align: center;
        border: 3px solid red;
        font-family: "times new roman", serif;
        background-color: lightsalmon;
    }

    .container {
        text-align: center;

        width: 500px;
        height: 50px;
        padding-top: 30px;


    }

    .b {
        text-align: center;
        position: absolute;
        top: 250px;
        left: 700px;
        height: 30px;
        width: 120px;
    }

    .c {
        text-align: center;
        position: absolute;
        top: 350px;
        left: 700px;
        height: 30px;
        width: 120px;
    }
</style>

<body>
    <link rel="stylesheet" type="text/css" href="style.css">


    <h1 class="a">User Page</h1>
    <div class="container">

        <form action="upload.php">

            <input type="SUBMIT" class="b" value="upload data" action="">
            <t>
                <t>
        </form><br><br><br>


        <form action="viewdata.php">
            <input type="submit" class="c" value="view data">
        </form>



    </div>
</body>

</html>